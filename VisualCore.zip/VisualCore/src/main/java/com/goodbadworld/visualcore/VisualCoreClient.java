package com.goodbadworld.visualcore;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/**
 * Visual Core client entrypoint. All features are client-side and do not alter
 * server state or bypass server rules.
 */
public final class VisualCoreClient implements ClientModInitializer {
    private static KeyBinding toggleHudKey;
    private static KeyBinding toggleCrosshairKey;
    private static KeyBinding toggleAuraKey;
    private static KeyBinding particleBurstKey;

    private static boolean hudEnabled = true;
    private static boolean customCrosshairEnabled = true;
    private static boolean auraEnabled = false;
    private static int tickCounter = 0;
    private static int toastTicks = 0;
    private static String toastMessage = "Visual Core enabled";

    @Override
    public void onInitializeClient() {
        toggleHudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.visualcore.toggle_hud", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O,
                "category.visualcore"));
        toggleCrosshairKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.visualcore.toggle_crosshair", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_P,
                "category.visualcore"));
        toggleAuraKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.visualcore.toggle_aura", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K,
                "category.visualcore"));
        particleBurstKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.visualcore.particle_burst", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J,
                "category.visualcore"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> tick(client));
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> renderHud(drawContext));
    }

    private static void tick(MinecraftClient client) {
        while (toggleHudKey.wasPressed()) {
            hudEnabled = !hudEnabled;
            showToast(hudEnabled ? "HUD: ON" : "HUD: OFF");
        }
        while (toggleCrosshairKey.wasPressed()) {
            customCrosshairEnabled = !customCrosshairEnabled;
            showToast(customCrosshairEnabled ? "Custom crosshair: ON" : "Custom crosshair: OFF");
        }
        while (toggleAuraKey.wasPressed()) {
            auraEnabled = !auraEnabled;
            showToast(auraEnabled ? "Ambient aura: ON" : "Ambient aura: OFF");
        }
        while (particleBurstKey.wasPressed()) {
            spawnBurst(client);
            showToast("Particle burst!");
        }

        if (toastTicks > 0) toastTicks--;
        tickCounter++;
        if (auraEnabled && client.player != null && client.world != null && tickCounter % 5 == 0) {
            spawnAura(client);
        }
    }

    private static void showToast(String message) {
        toastMessage = message;
        toastTicks = 45;
    }

    private static void spawnBurst(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        double x = client.player.getX();
        double y = client.player.getY() + 1.0;
        double z = client.player.getZ();
        for (int i = 0; i < 32; i++) {
            double angle = (Math.PI * 2.0 * i) / 32.0;
            double speed = 0.12 + (i % 4) * 0.025;
            client.world.addParticle(ParticleTypes.END_ROD, x, y, z,
                    Math.cos(angle) * speed, 0.035 + (i % 3) * 0.025, Math.sin(angle) * speed);
        }
        for (int i = 0; i < 10; i++) {
            double angle = (Math.PI * 2.0 * i) / 10.0;
            client.world.addParticle(ParticleTypes.HAPPY_VILLAGER, x + Math.cos(angle) * 0.35,
                    y + 0.2, z + Math.sin(angle) * 0.35,
                    Math.cos(angle) * 0.04, 0.06, Math.sin(angle) * 0.04);
        }
    }

    private static void spawnAura(MinecraftClient client) {
        double x = client.player.getX();
        double y = client.player.getY() + 0.15 + Math.random() * 1.55;
        double z = client.player.getZ();
        double angle = Math.random() * Math.PI * 2.0;
        double radius = 0.42 + Math.random() * 0.28;
        client.world.addParticle(ParticleTypes.END_ROD,
                x + Math.cos(angle) * radius, y, z + Math.sin(angle) * radius,
                0.0, 0.025, 0.0);
    }

    private static void renderHud(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.options == null) return;
        int width = context.getScaledWindowWidth();
        int height = context.getScaledWindowHeight();

        if (customCrosshairEnabled && client.player != null && !client.options.hudHidden) {
            // Four clean cyan bars with a small center gap.
            int cx = width / 2;
            int cy = height / 2;
            int color = 0xFF63F3FF;
            int shadow = 0xB9001018;
            context.fill(cx - 1, cy - 7, cx + 2, cy - 2, shadow);
            context.fill(cx - 1, cy + 2, cx + 2, cy + 7, shadow);
            context.fill(cx - 7, cy - 1, cx - 2, cy + 2, shadow);
            context.fill(cx + 2, cy - 1, cx + 7, cy + 2, shadow);
            context.fill(cx, cy - 6, cx + 1, cy - 2, color);
            context.fill(cx, cy + 2, cx + 1, cy + 6, color);
            context.fill(cx - 6, cy, cx - 2, cy + 1, color);
            context.fill(cx + 2, cy, cx + 6, cy + 1, color);
        }

        if (hudEnabled && !client.options.hudHidden) {
            int x = 8;
            int y = 8;
            int panelWidth = 116;
            int panelHeight = 42;
            context.fill(x, y, x + panelWidth, y + panelHeight, 0xA9101724);
            context.fill(x, y, x + 2, y + panelHeight, 0xFF63F3FF);
            context.fill(x + 2, y, x + panelWidth, y + 1, 0xAA63F3FF);
            context.drawTextWithShadow(client.textRenderer, Text.literal("VISUAL CORE"), x + 8, y + 5, 0xFF63F3FF);
            int fps = client.getCurrentFps();
            context.drawTextWithShadow(client.textRenderer, Text.literal("FPS  " + fps), x + 8, y + 18, 0xFFEAFBFF);
            String aura = auraEnabled ? "AURA ON" : "AURA OFF";
            context.drawTextWithShadow(client.textRenderer, Text.literal(aura), x + 61, y + 18,
                    auraEnabled ? 0xFF7DFFB2 : 0xFF8A99AA);
        }

        if (toastTicks > 0 && !client.options.hudHidden) {
            int alpha = MathHelper.clamp(toastTicks * 255 / 12, 0, 255);
            int color = (alpha << 24) | 0x00EAFBFF;
            int textWidth = client.textRenderer.getWidth(toastMessage);
            int x = (width - textWidth) / 2;
            int y = height / 2 + 24;
            context.fill(x - 7, y - 4, x + textWidth + 7, y + 13, (alpha / 2 << 24) | 0x00101724);
            context.drawTextWithShadow(client.textRenderer, Text.literal(toastMessage), x, y, color);
        }
    }
}
